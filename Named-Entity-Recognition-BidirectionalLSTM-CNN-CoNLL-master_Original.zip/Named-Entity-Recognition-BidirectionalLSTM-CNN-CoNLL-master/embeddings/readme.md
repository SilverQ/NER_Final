# Download

Download and store glove.6B.50d.txt from [Here](http://nlp.stanford.edu/data/glove.6B.zip)